package trainstation;

public class PassengerQueue {

    private Passenger[] queueArray;
    private int first;
    private int last;
    private int maxStayInQueue;
    private int maxLength;

    public PassengerQueue() {
        // Initialize queueArray
        queueArray=new Passenger[30];
        maxStayInQueue=30;
    }

    // Add passenger
    public void addPassenger(Passenger next)
    {
        //if queue is full then error msgs appears, if its not then adds passenger 
        if(!isQueueFull()) {
            queueArray[last] = next;
            last = (last + 1) % queueArray.length;
            maxLength++;
        }
        else
            System.out.println("Apologies queue is full");
    }
    // Removes passenger
    public Passenger removePassenger()
    {
        // checks to see if its empty if not then it removes the passenger from first
        if(!isQueueEmpty()) {
            Passenger passenger = queueArray[first];
            queueArray[first]=null;
            first = (first + 1) % queueArray.length;
            maxLength--;
            return passenger;
        }

        return null;
    }
    // Checks if queue is empty or not
    public boolean isQueueEmpty()
    {
        return maxLength==0;
    }
    // Checks if queue is full or not 
    public boolean isQueueFull()
    {
        return maxLength==maxStayInQueue;
    }
    // Displays queue
    public void displayQueue()
    {
        int factor=first;
        for(int i=0;i<maxLength;i++)
        {
            queueArray[factor].display();
            factor=(factor+1)%maxStayInQueue;
        }
    }

    // Gets the method for max stay in queue
    public int getMaxStay() {
        return maxStayInQueue;
    }
    // Gets method for max length in queue
    public int getLength() {
        return maxLength;
    }
}
