
package trainstation;


public class Passenger {
    // This stores their firstName
    private String firstName;
    // This stores their surName
    private String surName;
    // This stores the secondsInQueue
    private int secondsInQueue;



    public Passenger(String firstName, String surName) {
        this.firstName = firstName;
        this.surName = surName;
    }

    // This sets the method for the name
    public String getName() {
        return firstName+" "+surName;
    }
   
    public void setName(String name,String surName) {
        this.firstName = name;
        this.surName=surName;
    }
    // Gets method for seconds in queue
    public int getSecondsInQueue() {
        return secondsInQueue;
    }
    // Sets method for seconds in queue
    public void setSecondsInQueue(int secondsInQueue) {
        this.secondsInQueue = secondsInQueue;
    }

    // Displays method for passenger
    public void display()
    {
        System.out.println(getName()+" "+secondsInQueue);
    }
}
