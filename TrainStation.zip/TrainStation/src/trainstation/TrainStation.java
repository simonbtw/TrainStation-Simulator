//Simon Ibrahim | w1758459
package trainstation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class TrainStation 
{
    private static Passenger[] waitingRoom=new Passenger[30];
    private static PassengerQueue trainQueue=new PassengerQueue();
    private static Scanner sc=new Scanner(System.in);

    public static void main(String[] args) 
    {
        // Display the main menu
        displayMenu();
        while (true)
        {
            System.out.print("\nEnter the option: ");
            // Store user enter option
            String option=sc.nextLine();

            switch (option.toUpperCase()) 
            {
                case "A":
                    System.out.println("You have chosen to add a seat \n");
                    addPassenger();
                    break;
                case "V":
                   System.out.println("You have chosen to view all seats \n");
                    viewQueue();
                    break;
                case "D":
                    System.out.println("You have chosen to remove a customer from a seat \n");
                    deletePassenger();
                    break;
                case "S":
                    System.out.println("You have chosen to store the data \n");
                    storeData();
                    break;
                case "L":
                    System.out.println("You have chosen to load the data \n");
                    loadData();
                    break;
                default:
                    System.out.println("You have entered an invalid option");
                    System.out.println("The program will now end, Please come back again!");
                    return;
            }
        }
    }

    private static void displayMenu()
    {
        System.out.println("Enter 'A' to add a passenger");
        System.out.println("Enter 'V' to view all passengers");
        System.out.println("Enter 'D' to delete a passenger");
        System.out.println("Enter 'S' to store data");
        System.out.println("Enter 'L' to load data");
    }
    
     // Add passenger into train queue method
    private static void addPassenger() 
    {
        System.out.print("Enter first name: ");
        // Store first name from user input
        String firstName = sc.nextLine();
        System.out.print("Enter surname: ");
        // Store surname from user input
        String surName = sc.nextLine();

        Passenger passenger = new Passenger(firstName, surName);
        trainQueue.addPassenger(passenger);
    }
    
    // View train queue method
    private static void viewQueue() 
    {
        trainQueue.displayQueue();
    }
    
        // Delete passenger from train queue method
    private static void deletePassenger() 
    {
        System.out.println("Passenger deleted: ");
        trainQueue.removePassenger().display();
    }
    
        // Store trainQueue data into a plain text file method
    private static void storeData() 
    {
        try 
        {
            FileWriter myWriter = new FileWriter("savedata.txt");
            while (!trainQueue.isQueueEmpty()) 
            {
                Passenger remove = trainQueue.removePassenger();
                
                myWriter.write(remove.getName()+"\n");
            }
            myWriter.close();
        } catch (IOException e) 
        {
            System.out.println("Error occured");
            e.printStackTrace();
        }
    }
    
// Load data from file to train queue method
    
    private static void loadData() 
    {
        try 
        {
            File myObj = new File("savedata.txt");
            Scanner reader = new Scanner(myObj);
            while (reader.hasNextLine()) 
            {
                String s = reader.nextLine();
                // this splits the first name and surname
                String[] data = s.split(" ");
                Passenger passenger = new Passenger(data[0], data[1]);
                trainQueue.addPassenger(passenger);
            }
            reader.close();
        } catch (FileNotFoundException e) 
        {
            System.out.println("Error occured");
            e.printStackTrace();
        }
    }

}
